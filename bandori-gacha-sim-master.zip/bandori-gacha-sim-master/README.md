Contact:  
(Discord) sowon#0001  
(Reddit) /u/sowoneul  

TODO:
1. Allow spam click rolling
2. Add suitable feedback/ideas
